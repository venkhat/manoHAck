import React from "react";
import Weather from "./components/weather";
import Form from "./components/form";
import ReactTable from "react-table";
import 'react-table/react-table.css';
// import SWeather from "./components/stateless_weather";
// import SForm from "./components/stateless_form"
import Titles from "./components/titles";

const Api_Key = "8d2de98e089f1c28e1a22fc19a24ef04";
let i=0;
class App extends React.Component {

  state = {

    temperature: undefined,
    city: undefined,
    country: undefined,
    humidity: undefined,
    description: undefined,
    error: undefined,
    data: undefined,
  }

  getData =  async function(){
    i=i+1;
    const api_call = await fetch('http://api.openweathermap.org/data/2.5/weather');
      const response = await api_call.json();
      this.setState({
      data: [{
    name: 'Tanner Linsley',
    age: i,
    friend: {
      name: 'Jason Maurer',
      age: 23,
    }
  },{
    name: 'BTanner Linsley',
    age: 2667,
    friend: {
      name: 'Jason Maurer',
      age: 235,
    }
  },{
    name: 'CTanner Linsley',
    age: 265,
    friend: {
      name: 'Jason Maurer',
      age: 235,
    }
  }]

    })
  }

  loopFn = function(){
    setInterval(() =>{ this.getData()}, 2000);
    console.log('loop fn');
  }

  componentDidMount =   function(){
      this.loopFn();
  
  }
  //getWeather is a method we'll use to make the api call
  getWeather = async (e) => {

    const city = e.target.elements.city.value;
    const country = e.target.elements.country.value;
    e.preventDefault();   
    const api_call = await fetch(`http://api.openweathermap.org/data/2.5/weather?q=${city},${country}&appid=${Api_Key}`);
    const response = await api_call.json();
    console.log(response);
    if(city && country){
      this.setState({
        temperature: response.main.temp,
        city: response.name,
        country: response.sys.country,
        humidity: response.main.humidity,
        description: response.weather[0].description,
        error: ""
      })
    }else{
      this.setState({
        error: "Please input search values..."
      })
    }

    this.setState({
      data: [{
    name: 'Tanner Linsley',
    age: 26,
    friend: {
      name: 'Jason Maurer',
      age: 23,
    }
  },{
    name: 'Tanner Linsley',
    age: 26,
    friend: {
      name: 'Jason Maurer',
      age: 23,
    }
  },{
    name: 'Tanner Linsley',
    age: 26,
    friend: {
      name: 'Jason Maurer',
      age: 23,
    }
  }]

    })
  }

  
  
  render() {
    
    const columns = [{
    Header: 'Name',
    accessor: 'name' // String-based value accessors!
  }, {
    Header: 'Age',
    accessor: 'age',
    Cell: props => <span className='number'>{props.value}</span> // Custom cell components!
  }, {
    id: 'friendName', // Required because our accessor is not a string
    Header: 'Friend Name',
    accessor: d => d.friend.name // Custom value accessors!
  }, {
    Header: props => <span>Friend Age</span>, // Custom header components!
    accessor: 'friend.age'
  }]

    return (
      
      <div>
         <div className="wrapper">
          <div className="main">
            <div className="container">
              <ReactTable
                data={this.state.data}
                columns={columns}
              />
              <div className="row">
                <div className="col-xs-5 title-container">
                <Titles />
                </div>
                <div className="col-xs-7 form-container">
                <Form loadWeather={this.getWeather} />
                  <Weather
                    temperature={this.state.temperature}
                    city={this.state.city}
                    country={this.state.country}
                    humidity={this.state.humidity}
                    description={this.state.description}
                    error={this.state.error}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        
      </div>

    )
  }
}
export default App;
