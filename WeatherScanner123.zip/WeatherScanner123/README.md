# Weather Scanner
This is a React.Js project built to look further into stateless functional components in React.

It project is a weather application that calls the openweathermap api to render the conditions of supplied countries and cities.


## Installation

Same old way...

* git clone 
* npm install
* npm start
